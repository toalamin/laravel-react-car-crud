import * as React from "react";

const Footer = () => {
  return (
    <div className="">
      <p>&copy; 2022 - All rights reserved</p>
    </div>
  );
};

export default Footer;