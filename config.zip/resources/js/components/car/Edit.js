import React from 'react';
import { Container } from "react-bootstrap";

class Edit extends React.Component {
  render() {

    return (

    	<Container>
	      <h2>Edit Page</h2>
	    </Container>

    	)
  }
}


export default Edit;